// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "InteractiveViewportNavigationModule.h"

#include "LevelEditor.h"

#include "EditorViewportClient.h"
#include "Tools/NavigationInteractiveTool.h"
#include "EdModeInteractiveToolsContext.h"
#include "InteractiveNavigationUtils.h"
#include "SLevelViewport.h"
#include "NavigationWidgets/IconStyle.h"
#include "NavigationWidgets/SNavigationManagerWidget.h"
#include "Subsystems/PanelExtensionSubsystem.h"
#include "UObject/ObjectSaveContext.h"


#define LOCTEXT_NAMESPACE "BInteractiveViewportNavigationModule"

namespace DirectionIndicator
{
	const static FName ViewportExtensionIdentifier = TEXT("NavigationViewportExtension");
}
FString FInteractiveViewportNavigationModule::InteractiveToolName = TEXT("ViewportNavigationTool");

void FInteractiveViewportNavigationModule::StartupModule()
{
	FIconStyle::InitializeIcons();

	RegisterViewportTitleButton();
}

void FInteractiveViewportNavigationModule::ShutdownModule()
{
	FIconStyle::ShutDownIcons();
	UnregisterViewportTitleButton();
	
	UnregisterOnMapChanged();
	DestroyInteractiveNavigation();
	
	UnregisterOnChangedPIE();
}

void FInteractiveViewportNavigationModule::RegisterViewportTitleButton()
{
	if (GEditor)
	{
		if (UPanelExtensionSubsystem* PanelExtensionSubsystem = GEditor->GetEditorSubsystem<UPanelExtensionSubsystem>())
		{
			if (!PanelExtensionSubsystem->IsPanelFactoryRegistered(DirectionIndicator::ViewportExtensionIdentifier))
			{
				FPanelExtensionFactory LevelViewportToolbarExtensionWidget;
				LevelViewportToolbarExtensionWidget.CreateExtensionWidget = FPanelExtensionFactory::FCreateExtensionWidget::CreateRaw(this,&FInteractiveViewportNavigationModule::OnExtendLevelEditorViewportToolbar);
				LevelViewportToolbarExtensionWidget.Identifier = DirectionIndicator::ViewportExtensionIdentifier;

				PanelExtensionSubsystem->RegisterPanelFactory(TEXT("LevelViewportToolBar.RightExtension"), LevelViewportToolbarExtensionWidget);
			}
		}
	}
}

void FInteractiveViewportNavigationModule::UnregisterViewportTitleButton()
{
	if (GEditor)
	{
		if (UPanelExtensionSubsystem* PanelExtensionSubsystem = GEditor->GetEditorSubsystem<UPanelExtensionSubsystem>())
		{
			PanelExtensionSubsystem->UnregisterPanelFactory(DirectionIndicator::ViewportExtensionIdentifier);
		}
	}
}

TSharedRef<SWidget> FInteractiveViewportNavigationModule::OnExtendLevelEditorViewportToolbar(FWeakObjectPtr ExtensionContext)
{
	const FCheckBoxStyle& CheckBoxStyle = FIconStyle::Get().GetWidgetStyle<FCheckBoxStyle>(FName("BoxStyle"));

	return SNew(SCheckBox)
	.Style(&CheckBoxStyle)
	.ToolTipText(FText::FromName(TEXT("Show Interactive Navigation")))
	.OnCheckStateChanged_Lambda([&](const ECheckBoxState CheckBoxState)
	{
		switch (CheckBoxState)
		{
		case ECheckBoxState::Checked:
			StartInteractiveNavigationBehavior();
			RegisterOnMapChanged();
			DrawInteractiveNavigation();
			
			RegisterOnChangedPIE();
			
			break;
		case ECheckBoxState::Unchecked:
			EndInteractiveNavigationBehavior();
			UnregisterOnMapChanged();
			DestroyInteractiveNavigation();

			UnregisterOnChangedPIE();
			break;

			default:break;
		}
	});
}

void FInteractiveViewportNavigationModule::StartInteractiveNavigationBehavior()
{
	if (UModeManagerInteractiveToolsContext* ToolsContext = GLevelEditorModeTools().GetInteractiveToolsContext();
		ensure(ToolsContext))
	{
		if(bInteractiveNavigationBehaviorRegistered == false)
		{
			const TObjectPtr<UNavigationInteractiveToolBuilder> NavigationInteractiveToolBuilder = NewObject<UNavigationInteractiveToolBuilder>();
			ToolsContext->ToolManager->RegisterToolType(InteractiveToolName, NavigationInteractiveToolBuilder);
			bInteractiveNavigationBehaviorRegistered = true;
		}
		ToolsContext->StartTool(InteractiveToolName);
	}
}

void FInteractiveViewportNavigationModule::EndInteractiveNavigationBehavior() const
{
	if (UModeManagerInteractiveToolsContext* ToolsContext = GLevelEditorModeTools().GetInteractiveToolsContext();
		ensure(ToolsContext))
	{
		if(bInteractiveNavigationBehaviorRegistered == true)
		{
			ToolsContext->EndTool(EToolShutdownType::Completed);
		}
	}
}

void FInteractiveViewportNavigationModule::RegisterOnMapChanged()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	
	OnMapChangedDelegate = LevelEditorModule.OnMapChanged().AddLambda([&](UWorld* World, const EMapChangeType MapChangeType)
	{
		if(MapChangeType != EMapChangeType::SaveMap) //这里在保存关卡时不再重复执行
		{
			StartInteractiveNavigationBehavior();
		}
	});

	//处理其他关卡保存时, 若不更新也会失效, 原因未知
	OnMapSavedDelegate = FEditorDelegates::PostSaveWorldWithContext.AddLambda([&](UWorld* World, FObjectPostSaveContext ObjectSaveContext)
	{
		StartInteractiveNavigationBehavior();
	});
}

void FInteractiveViewportNavigationModule::UnregisterOnMapChanged() const
{
	if(OnMapChangedDelegate.IsValid())
	{
		FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
		LevelEditorModule.OnMapChanged().Remove(OnMapChangedDelegate);
	}

	if(OnMapSavedDelegate.IsValid())
	{
		FEditorDelegates::PostSaveWorldWithContext.Remove(OnMapSavedDelegate);
	}
}

void FInteractiveViewportNavigationModule::RegisterOnChangedPIE()
{
	OnPIEStartedDelegate = FEditorDelegates::PostPIEStarted.AddLambda([&](const bool bIsSimulating)
	{
		EndInteractiveNavigationBehavior();
		DestroyInteractiveNavigation();
	});
	
	OnPIEEndedDelegate = FEditorDelegates::EndPIE.AddLambda([&](const bool bIsSimulating)
	{
		StartInteractiveNavigationBehavior();
		DrawInteractiveNavigation();
	});
}

void FInteractiveViewportNavigationModule::UnregisterOnChangedPIE() const
{
	if(OnPIEStartedDelegate.IsValid())
	{
		FEditorDelegates::PostPIEStarted.Remove(OnPIEStartedDelegate);
	}

	if(OnPIEEndedDelegate.IsValid())
	{
		FEditorDelegates::EndPIE.Remove(OnPIEEndedDelegate);
	}
}

void FInteractiveViewportNavigationModule::DrawInteractiveNavigation()
{
	if(CheckViewportVerticalBox())
	{
		ViewportVerticalBox->InsertSlot(2)
		.AutoHeight()
		.Padding(FMargin(8))
		[
			SAssignNew(ManagerWidget,SNavigationManagerWidget)
		];
	}
}

void FInteractiveViewportNavigationModule::DestroyInteractiveNavigation()
{
	if(CheckViewportVerticalBox() && ManagerWidget.IsValid())
	{
		ViewportVerticalBox->RemoveSlot(ManagerWidget.ToSharedRef());
	}
}

bool FInteractiveViewportNavigationModule::CheckViewportVerticalBox()
{
	if(!ViewportVerticalBox.IsValid())
	{
		FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	
		if(const TSharedPtr<SLevelViewport> LevelViewport = LevelEditorModule.GetFirstActiveLevelViewport();
				LevelViewport.IsValid())
		{
			if(const TWeakPtr<SViewport> Viewport = LevelViewport->GetViewportWidget();
				Viewport.IsValid()) 
			{
				if(const TSharedPtr<SWidget> Overlay = Viewport.Pin()->GetContent())/*这是overlay, 因为不用它,就不cast了*/
					{
					if(Overlay->GetChildren()->Num() > 2)
					{
						if(const TSharedPtr<SVerticalBox> VerticalBox = StaticCastSharedPtr<SVerticalBox>(Overlay->GetChildren()->GetChildAt(2).ToSharedPtr()))
						{
							ViewportVerticalBox = VerticalBox;
							return true;
						}
					}
				}
			}
		}
	}
	else { return true; }
	return false;
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FInteractiveViewportNavigationModule, BInteractiveViewportNavigationEditorMode)